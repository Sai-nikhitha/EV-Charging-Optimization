# Instructions for the AI developing this repository

You are helping develop a final-year B.Tech major project titled **DRL-Based Intelligent EV Charging Optimization with Dynamic Priority Management and Solar Energy Integration**.

## First action
1. Inspect this entire repository and read `docs/MASTER_PROJECT_SPECIFICATION.txt`.
2. Read `docs/ARCHITECTURE.md` and `docs/DEVELOPMENT_PLAN.md`.
3. Inspect the existing code and tests before modifying anything.
4. Continue from the current implementation. Do not replace working code or restart from scratch unless a concrete defect requires it.
5. Work only on the next incomplete stage. Explain the objective, exact files to change, implementation, commands, expected results, and tests.

## Non-negotiable requirements
- Build a configurable simulation platform, not a solution tied to one real station.
- Use Python + Streamlit, Pandas + NumPy, Gymnasium, Stable-Baselines3 PPO, Plotly (or Matplotlib), and Pytest.
- The first scenario must contain exactly two scooters and one car:
  `SCOOTER-01`, `SCOOTER-02`, `CAR-01`.
- Keep station settings independent of EV settings.
- Distinguish station capacity, grid limit, solar availability, and per-EV maximum charging power.
- Validate SOC, capacities, charging powers, arrival/departure times, and station limits.
- Never charge before arrival, after departure, or above target SOC.
- Enforce station, grid, and per-EV physical limits in allocation logic, not only through reward penalties.
- Make baseline and PPO runs use identical scenario and environmental inputs.
- Do not fabricate metrics, charts, training results, savings, or model performance.
- Explicitly identify infeasible deadlines; do not promise impossible outcomes.
- Explain assumptions, reward terms, solar allocation, charging losses, and supported maximum EV slots.
- Do not claim arbitrary fleet-size support unless the observation/action spaces and trained policy truly support it.
- If PPO performs worse, report that honestly and show energy/deadline trade-offs.
- Do not claim connection to physical charging hardware.

## Workflow
Implement the stages in `docs/DEVELOPMENT_PLAN.md` in order. After each stage:
- provide complete code for changed files;
- run relevant automated tests;
- fix failures before moving on;
- state what is implemented and what remains;
- avoid large untested code dumps.

## Time constraint
The project is intended to be completed in approximately one month. Prioritize a reliable end-to-end simulation, reproducible evaluation, and a clear demonstration over unnecessary features. Do not remove required project objectives merely to save time; flag any proposed scope adjustment for approval.
