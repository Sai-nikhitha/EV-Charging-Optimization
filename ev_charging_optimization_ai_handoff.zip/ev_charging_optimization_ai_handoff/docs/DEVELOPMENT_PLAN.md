# One-month development plan

Work stage-by-stage; the schedule is a planning guide, not a claim that work is complete.

| Stage | Deliverable | Completion evidence |
|---|---|---|
| 1 | Domain models, station model, energy foundation, initial UI | Unit tests pass; three EVs configurable |
| 2 | Physical constraints and validation | Constraint and energy-accounting tests pass |
| 3 | Dynamic priority engine | Priority/feasibility tests and live table |
| 4 | Deterministic baseline policy | Order-independent allocation tests |
| 5 | Gymnasium environment | `check_env` and observation/action tests |
| 6 | PPO training and validation | Saved model, config, seeds, training logs |
| 7 | Simulation engine | Interval-by-interval schedule tests |
| 8 | Fair baseline/PPO evaluation | Same scenario inputs; computed metrics |
| 9 | Complete Streamlit dashboard | Inputs, controls, results and status states |
| 10 | Graphs and CSV export | Charts from actual data; exported schedule verified |
| 11 | Full testing and bug fixing | All tests pass; edge cases documented |
| 12 | Final documentation/demo | README, assumptions, limitations, reproducible demo |

## Suggested four-week allocation
- Week 1: Stages 1–4.
- Week 2: Stages 5–7 and first PPO training run.
- Week 3: Stages 8–10 and dashboard integration.
- Week 4: Stages 11–12, repeated experiments, fixes, report and demo.

If training quality or runtime is poor, do not conceal it. Prioritize a valid environment, reproducible baseline, measured PPO results, and transparent limitations.
