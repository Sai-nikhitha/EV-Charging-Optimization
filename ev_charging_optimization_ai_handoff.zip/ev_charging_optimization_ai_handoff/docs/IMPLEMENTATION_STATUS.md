# Implementation status at handoff

## Implemented in this starter bundle
- EV and charging station dataclasses with basic validation.
- Required-energy calculation.
- SOC update calculation.
- Solar-first aggregate interval energy accounting with grid import cap.
- Basic Streamlit form for the three initial demonstration vehicles and station settings.
- Unit tests for the above Stage 1 foundation.

## Not implemented yet
- Dynamic priority engine.
- Baseline charging allocation policy.
- Gymnasium environment.
- PPO training and inference.
- Full interval simulation engine.
- Fair baseline/PPO comparison metrics.
- Complete dashboard, graphs, detailed schedule and CSV export.
- Full scenario generation and multi-seed evaluation.

These are intentional next stages, not completed features. Implement them in the order in `DEVELOPMENT_PLAN.md`.
