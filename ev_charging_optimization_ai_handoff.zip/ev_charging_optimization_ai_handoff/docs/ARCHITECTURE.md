# Proposed architecture

## Layered design
1. **Domain models** — EV configuration/state and charging-station configuration.
2. **Energy accounting** — required energy, SOC transitions, grid/solar split, cost.
3. **Priority engine** — urgency and feasibility are separate outputs.
4. **Policies** — deterministic baseline and PPO policy adapter.
5. **Environment** — Gymnasium-compatible state/action/reward interface.
6. **Simulation engine** — time-step orchestration, arrivals/departures, allocations and records.
7. **Evaluation** — identical-scenario baseline/PPO metrics and honest comparisons.
8. **Presentation** — Streamlit input forms, tables, charts, CSV export.

## Suggested module responsibilities
- `models.py`: typed configuration dataclasses and validation.
- `energy.py`: pure calculation functions; no UI or RL dependencies.
- `priority.py`: priority score/classification and feasibility explanation.
- `baseline.py`: deterministic urgency-based or proportional allocation, order-independent tie handling.
- `environment.py`: Gymnasium `Env`, fixed maximum EV slots, explicit inactive-slot masks.
- `agent.py`: PPO training, model persistence, deterministic inference.
- `simulation.py`: shared simulation loop used by both policies.
- `evaluation.py`: aggregate metrics and comparison calculations.
- `visualization.py`: chart-ready data and Plotly figures.
- `app.py`: Streamlit interface only; keep business logic out of UI code.

## Physical constraints
For each interval, actual EV power must be no greater than:
- that EV's maximum charging power;
- station capacity remaining after other allocations;
- grid capacity plus solar power available under the documented solar policy;
- power needed to reach target SOC within the interval.

The station total and grid import must be checked independently. Grid import is not the same as station output when solar contributes.

## Energy accounting policy to document and test
For interval duration `dt_hours`:
- battery energy delivered = allocated EV charging power × `dt_hours`;
- charging losses are initially omitted (idealized 100% charging efficiency) unless a later approved model adds efficiency;
- solar is applied first to aggregate EV demand, up to solar availability;
- remaining demand is supplied by the grid, capped by the grid limit;
- any demand that cannot be supplied is curtailed by the allocator.
The exact solar sharing rule should be deterministic and consistent across baseline and PPO runs.

## Fixed-size PPO interface
Choose and document a maximum number of EV slots before training. Pad unused slots and include an active mask. Train/evaluate with varied active EV counts up to that maximum. Do not advertise support beyond the trained maximum.

## Reproducibility
Store scenario inputs, random seeds, training configuration, and model metadata. Baseline and PPO evaluation must receive the same immutable scenario copy and time-series profiles.
