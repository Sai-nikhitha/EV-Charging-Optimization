# DRL-Based Intelligent EV Charging Optimization

AI-ready starter repository for a simulation-based EV charging optimization major project.

## Important scope and integrity notes
- This is a **simulation-only** project. It does not connect to real charging hardware.
- The planned DRL algorithm is PPO using Gymnasium and Stable-Baselines3.
- The first demonstration scenario contains exactly `SCOOTER-01`, `SCOOTER-02`, and `CAR-01`.
- The initial scaffold implements the Stage 1 domain models, energy accounting foundation, a basic Streamlit configuration screen, and Stage 1 tests.
- Later modules are represented in the architecture and handoff plan; do not describe them as implemented until they are built and tested.
- PPO must not be assumed to outperform the baseline. All comparisons must use measured simulation outputs.

## Technology stack
Python, Streamlit, Pandas, NumPy, Gymnasium, Stable-Baselines3, Plotly, and Pytest.
The dashboard is implemented as a Streamlit web application, as specified in the project brief.

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Setup (macOS / Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run the initial UI
From the repository root:
```bash
streamlit run app.py
```

The initial UI lets you configure station limits and the three demonstration EVs. It is a configuration/model foundation, not the completed PPO dashboard.

## Run tests
```bash
pytest -q
```

## Repository map
```text
app.py                         Streamlit entry point
src/ev_charging/models.py      EV and charging-station domain models
src/ev_charging/energy.py      Required-energy, SOC and energy/cost accounting
src/ev_charging/priority.py    Stage 3 implementation target
src/ev_charging/baseline.py    Stage 4 implementation target
src/ev_charging/environment.py Stage 5 Gymnasium environment target
src/ev_charging/agent.py       Stage 6 PPO training/loading target
src/ev_charging/simulation.py  Stage 7 simulation engine target
src/ev_charging/evaluation.py  Stage 8 comparison and metrics target
src/ev_charging/visualization.py Stage 10 charts target
tests/                        Automated tests
docs/                         Full brief, architecture and AI handoff instructions
data/scenarios/                Reproducible scenario data
models/                        Trained model output location (initially empty)
outputs/                        Simulation and CSV output location (initially empty)
```

## Development order
Follow `docs/DEVELOPMENT_PLAN.md`. Implement one stage at a time, run tests after each stage, and do not skip ahead while tests fail.
