"""Stage 4 target: deterministic, order-independent baseline allocation."""
