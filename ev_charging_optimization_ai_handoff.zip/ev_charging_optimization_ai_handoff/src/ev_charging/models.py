"""Core configurable domain models for the EV charging simulation."""
from dataclasses import dataclass
from typing import Literal


VehicleType = Literal["Scooter", "Car"]


@dataclass
class EV:
    vehicle_id: str
    vehicle_type: VehicleType
    battery_capacity_kwh: float
    initial_soc_percent: float
    target_soc_percent: float
    max_charging_power_kw: float
    arrival_minute: int
    departure_minute: int

    def __post_init__(self) -> None:
        if not self.vehicle_id.strip():
            raise ValueError("Vehicle ID cannot be empty.")
        if self.vehicle_type not in ("Scooter", "Car"):
            raise ValueError("Vehicle type must be Scooter or Car.")
        if self.battery_capacity_kwh <= 0:
            raise ValueError("Battery capacity must be greater than zero.")
        if not 0 <= self.initial_soc_percent <= 100:
            raise ValueError("Initial SOC must be between 0 and 100.")
        if not 0 <= self.target_soc_percent <= 100:
            raise ValueError("Target SOC must be between 0 and 100.")
        if self.target_soc_percent < self.initial_soc_percent:
            raise ValueError("Target SOC must be greater than or equal to initial SOC.")
        if self.max_charging_power_kw <= 0:
            raise ValueError("Maximum charging power must be greater than zero.")
        if self.arrival_minute < 0:
            raise ValueError("Arrival time cannot be negative.")
        if self.departure_minute <= self.arrival_minute:
            raise ValueError("Departure must be later than arrival.")

    @property
    def required_energy_kwh(self) -> float:
        """Energy needed to move from initial SOC to target SOC."""
        return max(
            0.0,
            (self.target_soc_percent - self.initial_soc_percent)
            / 100.0 * self.battery_capacity_kwh,
        )


@dataclass
class ChargingStation:
    station_capacity_kw: float
    grid_limit_kw: float
    solar_enabled: bool = False
    manual_solar_power_kw: float = 0.0
    tariff_rupees_per_kwh: float = 8.0
    interval_minutes: int = 15
    simulation_duration_minutes: int = 1440

    def __post_init__(self) -> None:
        if self.station_capacity_kw <= 0:
            raise ValueError("Station capacity must be greater than zero.")
        if self.grid_limit_kw < 0:
            raise ValueError("Grid limit cannot be negative.")
        if self.manual_solar_power_kw < 0:
            raise ValueError("Solar power cannot be negative.")
        if self.tariff_rupees_per_kwh < 0:
            raise ValueError("Tariff cannot be negative.")
        if self.interval_minutes <= 0:
            raise ValueError("Interval must be greater than zero.")
        if self.simulation_duration_minutes <= 0:
            raise ValueError("Simulation duration must be greater than zero.")
        if self.simulation_duration_minutes % self.interval_minutes != 0:
            raise ValueError("Simulation duration must be divisible by interval length.")

    @property
    def available_solar_power_kw(self) -> float:
        return self.manual_solar_power_kw if self.solar_enabled else 0.0
