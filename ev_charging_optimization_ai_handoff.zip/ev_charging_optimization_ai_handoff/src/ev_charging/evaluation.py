"""Stage 8 target: fair baseline-versus-PPO metrics and comparison."""
