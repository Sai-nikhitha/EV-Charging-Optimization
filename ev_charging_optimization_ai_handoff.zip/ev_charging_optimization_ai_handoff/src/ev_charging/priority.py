"""Stage 3 target: implement dynamic urgency and feasibility calculations.

Keep urgency distinct from physical feasibility. Do not invent arbitrary weights
without documenting and testing their rationale.
"""
