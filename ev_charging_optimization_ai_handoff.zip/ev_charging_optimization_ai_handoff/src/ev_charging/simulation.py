"""Stage 7 target: shared time-step simulation engine for all policies."""
