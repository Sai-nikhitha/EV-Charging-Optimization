"""Stage 10 target: Plotly charts generated only from simulation records."""
