"""Pure energy-accounting functions. Charging losses are omitted in Stage 1."""
from dataclasses import dataclass


@dataclass(frozen=True)
class EnergySupply:
    battery_energy_kwh: float
    solar_energy_kwh: float
    grid_energy_kwh: float
    grid_cost_rupees: float


def required_energy_kwh(
    battery_capacity_kwh: float,
    current_soc_percent: float,
    target_soc_percent: float,
) -> float:
    if battery_capacity_kwh <= 0:
        raise ValueError("Battery capacity must be greater than zero.")
    if not 0 <= current_soc_percent <= 100:
        raise ValueError("Current SOC must be between 0 and 100.")
    if not 0 <= target_soc_percent <= 100:
        raise ValueError("Target SOC must be between 0 and 100.")
    if target_soc_percent < current_soc_percent:
        raise ValueError("Target SOC cannot be lower than current SOC.")
    return max(0.0, (target_soc_percent-current_soc_percent)/100 * battery_capacity_kwh)


def update_soc_percent(
    current_soc_percent: float,
    battery_capacity_kwh: float,
    energy_delivered_kwh: float,
) -> float:
    if battery_capacity_kwh <= 0:
        raise ValueError("Battery capacity must be greater than zero.")
    if not 0 <= current_soc_percent <= 100:
        raise ValueError("Current SOC must be between 0 and 100.")
    if energy_delivered_kwh < 0:
        raise ValueError("Delivered energy cannot be negative.")
    return min(100.0, current_soc_percent + energy_delivered_kwh / battery_capacity_kwh * 100)


def account_interval_energy(
    requested_power_kw: float,
    solar_available_kw: float,
    grid_limit_kw: float,
    interval_minutes: int,
    tariff_rupees_per_kwh: float,
) -> EnergySupply:
    """Solar-first accounting for one aggregate load, with grid import capped."""
    if min(requested_power_kw, solar_available_kw, grid_limit_kw, tariff_rupees_per_kwh) < 0:
        raise ValueError("Power, tariff, and energy inputs cannot be negative.")
    if interval_minutes <= 0:
        raise ValueError("Interval must be greater than zero.")

    dt = interval_minutes / 60.0
    solar_power = min(requested_power_kw, solar_available_kw)
    remaining_power = requested_power_kw - solar_power
    grid_power = min(remaining_power, grid_limit_kw)
    supplied_power = solar_power + grid_power

    solar_kwh = solar_power * dt
    grid_kwh = grid_power * dt
    return EnergySupply(
        battery_energy_kwh=supplied_power * dt,
        solar_energy_kwh=solar_kwh,
        grid_energy_kwh=grid_kwh,
        grid_cost_rupees=grid_kwh * tariff_rupees_per_kwh,
    )
