"""Initial Streamlit configuration UI for Stage 1."""
import streamlit as st
from src.ev_charging.models import EV, ChargingStation

st.set_page_config(page_title="EV Charging Optimization", page_icon="⚡", layout="wide")
st.title("⚡ Intelligent EV Charging Optimization")
st.caption("Simulation-based project | Initial configuration interface (Stage 1)")

st.info(
    "Configure the station and the three demonstration EVs. This initial screen "
    "validates and previews inputs; simulation, baseline and PPO controls are added "
    "in later development stages."
)

with st.sidebar:
    st.header("Charging station")
    station_capacity = st.number_input("Total station capacity (kW)", min_value=0.1, value=10.0, step=0.5)
    grid_limit = st.number_input("Maximum grid power (kW)", min_value=0.0, value=8.0, step=0.5)
    solar_enabled = st.toggle("Enable solar energy", value=True)
    solar_power = st.number_input("Manual solar power available (kW)", min_value=0.0, value=2.0, step=0.5, disabled=not solar_enabled)
    tariff = st.number_input("Electricity tariff (₹/kWh)", min_value=0.0, value=8.0, step=0.5)
    interval = st.selectbox("Simulation interval", [5, 10, 15, 30, 60], index=2)
    duration = st.number_input("Simulation duration (minutes)", min_value=interval, value=1440, step=interval)

st.subheader("Vehicle configuration")
defaults = [
    ("SCOOTER-01", "Scooter", 3.5, 20.0, 90.0, 1.5, 0, 480),
    ("SCOOTER-02", "Scooter", 3.5, 30.0, 90.0, 1.5, 30, 540),
    ("CAR-01", "Car", 40.0, 25.0, 80.0, 7.0, 0, 600),
]
evs = []
cols = st.columns(3)
for i, default in enumerate(defaults):
    vehicle_id, vehicle_type, capacity, initial_soc, target_soc, max_power, arrival, departure = default
    with cols[i]:
        st.markdown(f"**{vehicle_id}**")
        vid = st.text_input("Vehicle ID", vehicle_id, key=f"id_{i}")
        vtype = st.selectbox("Vehicle type", ["Scooter", "Car"], index=0 if vehicle_type == "Scooter" else 1, key=f"type_{i}")
        cap = st.number_input("Battery capacity (kWh)", min_value=0.1, value=float(capacity), step=0.5, key=f"cap_{i}")
        initial = st.number_input("Initial SOC (%)", min_value=0.0, max_value=100.0, value=float(initial_soc), step=1.0, key=f"initial_{i}")
        target = st.number_input("Target SOC (%)", min_value=0.0, max_value=100.0, value=float(target_soc), step=1.0, key=f"target_{i}")
        max_kw = st.number_input("Maximum charging power (kW)", min_value=0.1, value=float(max_power), step=0.1, key=f"power_{i}")
        arrive = st.number_input("Arrival (minute)", min_value=0, value=int(arrival), step=5, key=f"arrive_{i}")
        depart = st.number_input("Departure deadline (minute)", min_value=1, value=int(departure), step=5, key=f"depart_{i}")
        try:
            evs.append(EV(vid, vtype, cap, initial, target, max_kw, int(arrive), int(depart)))
        except ValueError as exc:
            st.error(f"{vid or vehicle_id}: {exc}")

st.divider()
if st.button("Validate and preview configuration", type="primary"):
    try:
        station = ChargingStation(
            station_capacity_kw=float(station_capacity),
            grid_limit_kw=float(grid_limit),
            solar_enabled=solar_enabled,
            manual_solar_power_kw=float(solar_power),
            tariff_rupees_per_kwh=float(tariff),
            interval_minutes=int(interval),
            simulation_duration_minutes=int(duration),
        )
        if len(evs) != 3:
            raise ValueError("Please correct all three EV configurations.")
        st.success("Station and EV configuration is valid.")
        st.subheader("Station summary")
        st.json({
            "station_capacity_kw": station.station_capacity_kw,
            "grid_limit_kw": station.grid_limit_kw,
            "solar_available_kw": station.available_solar_power_kw,
            "tariff_rupees_per_kwh": station.tariff_rupees_per_kwh,
            "interval_minutes": station.interval_minutes,
            "simulation_duration_minutes": station.simulation_duration_minutes,
        })
        st.subheader("EV summary")
        st.dataframe([{
            "EV ID": ev.vehicle_id,
            "Type": ev.vehicle_type,
            "Battery (kWh)": ev.battery_capacity_kwh,
            "Initial SOC (%)": ev.initial_soc_percent,
            "Target SOC (%)": ev.target_soc_percent,
            "Required energy (kWh)": round(ev.required_energy_kwh, 3),
            "Max power (kW)": ev.max_charging_power_kw,
            "Arrival (min)": ev.arrival_minute,
            "Departure (min)": ev.departure_minute,
        } for ev in evs], use_container_width=True)
    except ValueError as exc:
        st.error(str(exc))

st.caption("Illustrative default values only. They are configurable and are not universal vehicle specifications.")
