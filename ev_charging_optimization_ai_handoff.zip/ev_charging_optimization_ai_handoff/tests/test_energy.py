import pytest
from src.ev_charging.energy import (
    required_energy_kwh, update_soc_percent, account_interval_energy
)


def test_required_energy():
    assert required_energy_kwh(40, 25, 80) == pytest.approx(22.0)


def test_soc_update():
    assert update_soc_percent(50, 10, 2.5) == pytest.approx(75.0)


def test_soc_is_capped_at_100():
    assert update_soc_percent(95, 10, 2) == pytest.approx(100.0)


def test_solar_first_energy_accounting():
    result = account_interval_energy(5, 2, 4, 30, 10)
    assert result.battery_energy_kwh == pytest.approx(2.5)
    assert result.solar_energy_kwh == pytest.approx(1.0)
    assert result.grid_energy_kwh == pytest.approx(1.5)
    assert result.grid_cost_rupees == pytest.approx(15.0)


def test_grid_limit_curtailed():
    result = account_interval_energy(8, 1, 2, 60, 5)
    assert result.battery_energy_kwh == pytest.approx(3.0)
    assert result.grid_energy_kwh == pytest.approx(2.0)


def test_invalid_soc_rejected():
    with pytest.raises(ValueError):
        required_energy_kwh(10, 110, 100)
