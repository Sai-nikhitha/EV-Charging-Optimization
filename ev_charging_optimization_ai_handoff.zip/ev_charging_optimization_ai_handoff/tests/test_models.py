import pytest
from src.ev_charging.models import EV, ChargingStation


def test_demo_ev_models():
    scooter = EV("SCOOTER-01", "Scooter", 3.5, 20, 90, 1.5, 0, 480)
    car = EV("CAR-01", "Car", 40, 25, 80, 7, 0, 600)
    assert scooter.required_energy_kwh == pytest.approx(2.45)
    assert car.required_energy_kwh == pytest.approx(22.0)


def test_target_soc_must_not_be_below_initial():
    with pytest.raises(ValueError):
        EV("EV-1", "Car", 40, 80, 70, 7, 0, 60)


def test_station_solar_switch():
    station = ChargingStation(10, 8, True, 2)
    assert station.available_solar_power_kw == 2
    station.solar_enabled = False
    assert station.available_solar_power_kw == 0


def test_station_duration_must_match_interval():
    with pytest.raises(ValueError):
        ChargingStation(10, 8, interval_minutes=15, simulation_duration_minutes=100)
